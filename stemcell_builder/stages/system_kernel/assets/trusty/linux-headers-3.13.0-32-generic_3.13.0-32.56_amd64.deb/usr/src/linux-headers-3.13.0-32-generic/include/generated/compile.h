/* This file is auto generated, version 56-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#56-Ubuntu SMP Mon Jul 7 11:32:12 UTC 2014"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "toyol"
#define LINUX_COMPILER "gcc version 4.8.2 (Ubuntu 4.8.2-19ubuntu1) "
