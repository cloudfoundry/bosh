#define UTS_RELEASE "3.0.0-32-virtual"
