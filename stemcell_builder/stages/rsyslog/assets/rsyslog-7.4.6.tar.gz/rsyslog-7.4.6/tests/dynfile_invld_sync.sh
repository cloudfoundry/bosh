echo "\$OMFileAsyncWriting off" > rsyslog.action.1.include
source $srcdir/dynfile_cachemiss.sh
