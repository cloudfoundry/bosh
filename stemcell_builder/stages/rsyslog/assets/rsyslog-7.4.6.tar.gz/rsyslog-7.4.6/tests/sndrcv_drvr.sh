source $srcdir/sndrcv_drvr_noexit.sh $1 $2
